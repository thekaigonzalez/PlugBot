module.exports = class {
    basic(c,m,a) {
        m.channel.send("hello!");
    }
}